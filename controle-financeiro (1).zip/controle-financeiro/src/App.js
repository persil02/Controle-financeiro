
import { useState, useEffect } from 'react';
import { Pie, Bar } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement } from 'chart.js';

ChartJS.register(ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement);

function App() {
  const [entries, setEntries] = useState([]);
  const [form, setForm] = useState({
    tipo: 'Receita',
    categoria: '',
    valor: ''
  });

  useEffect(() => {
    const saved = localStorage.getItem('finance_entries');
    if (saved) setEntries(JSON.parse(saved));
  }, []);

  useEffect(() => {
    localStorage.setItem('finance_entries', JSON.stringify(entries));
  }, [entries]);

  const handleSubmit = () => {
    if (!form.categoria || !form.valor) return;
    setEntries([...entries, { ...form, valor: parseFloat(form.valor) }]);
    setForm({ tipo: 'Receita', categoria: '', valor: '' });
  };

  const receitas = entries.filter(e => e.tipo === 'Receita').reduce((acc, cur) => acc + cur.valor, 0);
  const despesas = entries.filter(e => e.tipo === 'Despesa').reduce((acc, cur) => acc + cur.valor, 0);

  const categorias = {};
  entries.forEach(e => {
    categorias[e.categoria] = (categorias[e.categoria] || 0) + e.valor;
  });

  const pieData = {
    labels: Object.keys(categorias),
    datasets: [{
      data: Object.values(categorias),
      backgroundColor: ['#36A2EB', '#FF6384', '#FFCE56', '#4BC0C0', '#9966FF'],
    }]
  };

  const barData = {
    labels: ['Receitas', 'Despesas'],
    datasets: [{
      label: 'Total',
      data: [receitas, despesas],
      backgroundColor: ['#4CAF50', '#F44336']
    }]
  };

  return (
    <div style={{ padding: '20px', maxWidth: '900px', margin: 'auto' }}>
      <h1>Controle Financeiro</h1>

      <div style={{ display: 'flex', gap: '10px', marginBottom: '20px' }}>
        <select value={form.tipo} onChange={e => setForm({ ...form, tipo: e.target.value })}>
          <option>Receita</option>
          <option>Despesa</option>
        </select>
        <input placeholder="Categoria" value={form.categoria} onChange={e => setForm({ ...form, categoria: e.target.value })} />
        <input type="number" placeholder="Valor" value={form.valor} onChange={e => setForm({ ...form, valor: e.target.value })} />
        <button onClick={handleSubmit}>Adicionar</button>
      </div>

      <div style={{ display: 'flex', gap: '20px' }}>
        <div style={{ width: '45%' }}><Pie data={pieData} /></div>
        <div style={{ width: '45%' }}><Bar data={barData} /></div>
      </div>

      <ul>
        {entries.map((e, i) => (
          <li key={i}>{e.tipo} - {e.categoria}: R$ {e.valor.toFixed(2)}</li>
        ))}
      </ul>
    </div>
  );
}

export default App;
